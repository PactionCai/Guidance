#include "func.h"

int func(void)
{
    return 0;
}
