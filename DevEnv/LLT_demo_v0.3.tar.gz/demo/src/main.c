#include <stdio.h>
#include "func.h"

#ifndef LLT
int main(int argc, char **argv)
{
    (void)func();
    printf("Hello World!\n");
	return 0;
}
#endif // LLT
