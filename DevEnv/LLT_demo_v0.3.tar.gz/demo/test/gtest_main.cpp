#include <iostream>
#include "gtest/gtest.h"
#include "mockcpp/mockcpp.hpp"
#include "func.h"

TEST(TestAdd, TestCase1)
{
    ASSERT_EQ(0, func());
    MOCKER(func)
        .stubs()
        .will(returnValue((int)1));
    ASSERT_EQ(1, func());
}

#ifdef LLT
int main(int argc, char **argv)
{
	std::cout << "gtest begin.." << std::endl;
	testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}
#endif
