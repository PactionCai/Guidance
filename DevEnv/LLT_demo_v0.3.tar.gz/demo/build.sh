#!/bin/bash

CURRENT_DIR=$(cd "$(dirname "$0")";pwd)

declare -A BUILD_TYPE_LIST=([0]="Release" [1]="Debug" [2]="LLT")
BUILD_TYPE=${BUILD_TYPE_LIST[0]}

function isBuildTypeInList()
{
    local buildType="$1"
    for type in ${BUILD_TYPE_LIST[@]}
    do
        if [ x"${buildType}" = x"${type}" ]; then
            return 0
        fi
    done
    return 1
}

function installLLTLib()
{
    local downloadDir=${CURRENT_DIR}/download
    if [ ! -d ${downloadDir} ]; then
        mkdir -p ${downloadDir}
    fi

    # local downloadDir=${CURRENT_DIR}/download
    # curl -o ${downloadDir}/googletest-release-1.11.0.tar.gz https://github.com/google/googletest/archive/refs/tags/release-1.11.0.tar.gz
    # if [ $? -ne 0 ]; then
    #    echo "Error: download google test failed"
    #    return 1
    # fi
    tar -zxvf ${downloadDir}/googletest-release-1.11.0.tar.gz -C ${CURRENT_DIR}/3rdparty
    if [ $? -ne 0 ]; then
        echo "Error: decompress google test failed"
        return 1
    fi
    cd ${CURRENT_DIR}/3rdparty/googletest-release-1.11.0 && cmake . && make

    # curl -o ${downloadDir}/mockcpp-2.6.tar.gz https://storage.googleapis.com/google-code-archive-downloads/v2/code.google.com/mockcpp/mockcpp-2.6.tar.gz
    # if [ $? -ne 0 ]; then
    #    echo "Error: download mockcpp failed"
    #    return 1
    # fi
    tar -zxvf ${downloadDir}/mockcpp-2.6.tar.gz -C ${CURRENT_DIR}/3rdparty
    if [ $? -ne 0 ]; then
        echo "Error: decompress google test failed"
        return 1
    fi
    sed -i '58 i#if __cplusplus < 199711L' ${CURRENT_DIR}/3rdparty/mockcpp/include/mockcpp/mockcpp.h
    sed -i '64 i#endif // __cplusplus' ${CURRENT_DIR}/3rdparty/mockcpp/include/mockcpp/mockcpp.h
    cd ${CURRENT_DIR}/3rdparty/mockcpp && cmake . && make

    return 0
}

function compileProject()
{
    cd ${CURRENT_DIR}/build && cmake .. -DBUILD_TYPE:STRING=${BUILD_TYPE} && make
    return 0
}

function runLLT()
{
    cd ${CURRENT_DIR}/bin && ./demo_test
    return 0
}

function cleanProject()
{
    cd ${CURRENT_DIR}/build && make clean >/dev/null 2>&1
    rm -rf ${CURRENT_DIR}/bin/* >/dev/null 2>&1
    rm -rf ${CURRENT_DIR}/build/* >/dev/null 2>&1
    rm -rf ${CURRENT_DIR}/3rdparty/* >/dev/null 2>&1
    return 0
}

function main()
{
    if [ x"${BUILD_TYPE}" = x"LLT" ]; then
        installLLTLib
        if [ $? -ne 0 ]; then
            echo "Error: install LLT libraty failed"
            return 1
        fi
    fi
    
    compileProject

    if [ x"${BUILD_TYPE}" = x"LLT" ]; then
        runLLT
    fi
}

function printfUsage()
{
    echo "Usage: $0 [OPTION]..."
    echo "Build the project."
    echo "-t    specified the build type, such ad Release, Debug, LLT."
    return 0;
}

if [ x"$1" = x"clean" ]; then
    cleanProject
    exit $?
fi

while getopts t: opt
do
    case "${opt}" in
        t)
            BUILD_TYPE="${OPTARG}"
            ;;
        *)
            echo "Unknown option: ${opt}"
            printfUsage
            exit 1
            ;;
    esac
done

isBuildTypeInList "${BUILD_TYPE}"
if [ $? -ne 0 ]; then
    echo "Unknown build type: ${BUILD_TYPE}"
    printfUsage
    exit 1
fi

main "$*"
