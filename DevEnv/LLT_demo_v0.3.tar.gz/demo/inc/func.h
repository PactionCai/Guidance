#ifndef __FUNC_H__
#define __FUNC_H__

#include <stdio.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

int func(void);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __FUNC_H__ */